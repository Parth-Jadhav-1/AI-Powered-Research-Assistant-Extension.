package com.example.entity;

import lombok.Data;

@Data
public class ResearchRequest {
    private String content;
    private String operation;
}
